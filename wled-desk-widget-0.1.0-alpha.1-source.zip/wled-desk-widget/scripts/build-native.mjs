import {spawnSync} from 'node:child_process';import {fileURLToPath} from 'node:url';import {resolve} from 'node:path';import {mkdir,copyFile,readdir,writeFile,readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
function run(file,args,cwd=root){const result=spawnSync(file,args,{cwd,stdio:'inherit',windowsHide:true});if(result.error)throw result.error;if(result.status!==0)process.exit(result.status||1);}
run(process.execPath,[resolve(root,'scripts/build-frontend.mjs')]);
run(process.execPath,[resolve(root,'node_modules/@tauri-apps/cli/tauri.js'),'build','--locked','--bundles','nsis'],resolve(root,'apps/desktop'));
const dest=resolve(root,'release-local');await mkdir(dest,{recursive:true});
const source=resolve(root,'apps/desktop/src-tauri/target/release');
const installers=(await readdir(resolve(source,'bundle/nsis'))).filter(n=>n.endsWith('.exe'));
if(!installers.length)throw Error('Installer not produced');
for(const name of installers)await copyFile(resolve(source,'bundle/nsis',name),resolve(dest,name));
await copyFile(resolve(source,'wled-desk-widget.exe'),resolve(dest,'wled-desk-widget.exe'));
const sums=[];for(const name of [...installers,'wled-desk-widget.exe'])sums.push(createHash('sha256').update(await readFile(resolve(dest,name))).digest('hex')+'  '+name);
await writeFile(resolve(dest,'SHA256SUMS.txt'),sums.join('\n')+'\n');console.log('Windows artifacts: '+dest);
