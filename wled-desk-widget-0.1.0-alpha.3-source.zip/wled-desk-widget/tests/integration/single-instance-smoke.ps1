$ErrorActionPreference='Stop'
$widgetExe=Join-Path (Get-Location) 'release-local\wled-desk-widget.exe'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class WidgetWindows {
 public delegate bool EnumProc(IntPtr hwnd,IntPtr param);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc callback,IntPtr param);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint processId);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hwnd,StringBuilder text,int size);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
 [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hwnd);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hwnd,uint message,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd,int command);
 public static IntPtr Find(uint id){IntPtr found=IntPtr.Zero;EnumWindows((hwnd,p)=>{uint owner;GetWindowThreadProcessId(hwnd,out owner);var title=new StringBuilder(256);GetWindowText(hwnd,title,256);if(owner==id&&title.ToString()=="WLED Desk | Widget"){found=hwnd;return false;}return true;},IntPtr.Zero);return found;}
}
'@
function Wait-Until([scriptblock]$Condition,[string]$Description){for($i=0;$i -lt 150;$i++){if(& $Condition){return};Start-Sleep -Milliseconds 100};throw "Timed out: $Description"}
function Instances {@(Get-Process -Name wled-desk-widget -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq $widgetExe})}
function Relaunch { $secondary=Start-Process -FilePath $widgetExe -PassThru -WindowStyle Hidden; if(-not $secondary.WaitForExit(15000)){throw 'Second launch did not exit'};if(@(Instances).Count -ne 1){throw 'Multiple widget processes remain'} }
if(@(Instances).Count -eq 0){Start-Process -FilePath $widgetExe -WindowStyle Hidden}
Wait-Until { @(Instances).Count -eq 1 } 'first instance'
$first=(Instances)[0];$firstId=$first.Id
Wait-Until { [WidgetWindows]::Find($firstId) -ne [IntPtr]::Zero } 'main window'
$handle=[WidgetWindows]::Find($firstId)
Wait-Until { [WidgetWindows]::IsWindowVisible($handle) } 'visible main window'
Relaunch
if((Instances)[0].Id -ne $firstId){throw 'First instance was replaced'}
[void][WidgetWindows]::PostMessage($handle,0x10,[IntPtr]::Zero,[IntPtr]::Zero)
Wait-Until { -not [WidgetWindows]::IsWindowVisible($handle) } 'close hides in tray'
Relaunch
Wait-Until { [WidgetWindows]::IsWindowVisible($handle) } 'relaunch restores hidden window'
[void][WidgetWindows]::ShowWindow($handle,6)
Wait-Until { [WidgetWindows]::IsIconic($handle) } 'minimized window'
Relaunch
Wait-Until { -not [WidgetWindows]::IsIconic($handle) -and [WidgetWindows]::IsWindowVisible($handle) } 'relaunch restores minimized window'
$launches=@(1..3 | ForEach-Object {Start-Process -FilePath $widgetExe -PassThru -WindowStyle Hidden})
foreach($secondary in $launches){if(-not $secondary.WaitForExit(15000)){throw 'Burst launch did not exit'}}
Wait-Until { @(Instances).Count -eq 1 } 'one process after burst'
if((Instances)[0].Id -ne $firstId){throw 'Burst replaced the first instance'}
Write-Output 'Single instance passed: duplicate exit, same process retained, hidden and minimized window restored, three simultaneous launches leave one widget.'
