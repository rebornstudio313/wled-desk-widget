// Keep Windows non-client decorations out of a fixed transparent WebView window.
pub fn clear(window: &tauri::WebviewWindow) {
    #[cfg(windows)]
    unsafe {
        use windows_sys::Win32::UI::WindowsAndMessaging::{
            GetWindowLongPtrW, SetWindowLongPtrW, SetWindowPos, GWL_STYLE, SWP_FRAMECHANGED,
            SWP_NOACTIVATE, SWP_NOMOVE, SWP_NOSIZE, SWP_NOZORDER, WS_CAPTION, WS_THICKFRAME,
        };
        if let Ok(hwnd) = window.hwnd() {
            let style = GetWindowLongPtrW(hwnd.0 as _, GWL_STYLE);
            let next = style & !((WS_CAPTION | WS_THICKFRAME) as isize);
            if next != style {
                SetWindowLongPtrW(hwnd.0 as _, GWL_STYLE, next);
                SetWindowPos(
                    hwnd.0 as _,
                    std::ptr::null_mut(),
                    0,
                    0,
                    0,
                    0,
                    SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE,
                );
            }
        }
    }
}

pub fn round(window: &tauri::WebviewWindow) {
    #[cfg(windows)]
    unsafe {
        use windows_sys::Win32::Graphics::Gdi::{CreateRoundRectRgn, DeleteObject, SetWindowRgn};
        if let (Ok(hwnd), Ok(size), Ok(scale)) =
            (window.hwnd(), window.outer_size(), window.scale_factor())
        {
            let radius = (32.0 * scale).round() as i32;
            let region =
                CreateRoundRectRgn(0, 0, size.width as i32, size.height as i32, radius, radius);
            if !region.is_null() && SetWindowRgn(hwnd.0 as _, region, 1) == 0 {
                DeleteObject(region);
            }
        }
    }
}
